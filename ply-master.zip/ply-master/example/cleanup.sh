#!/bin/sh
rm -f */*.pyc */parsetab.py */parser.out */*~ */*.class
